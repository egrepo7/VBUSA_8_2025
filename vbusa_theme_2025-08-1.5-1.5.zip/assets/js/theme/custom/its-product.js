/**
 * IntuitSolutions - Custom JS that fires on the PDP
 */

export default class ITSProduct {
    constructor(context) {
    }
}
