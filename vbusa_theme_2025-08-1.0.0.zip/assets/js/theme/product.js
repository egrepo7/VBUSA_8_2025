/*
 Import all product specific js
 */
import PageManager from './page-manager';
import Review from './product/reviews';
import collapsibleFactory from './common/collapsible';
import ProductDetails from './common/product-details';
import videoGallery from './product/video-gallery';
import { classifyForm } from './common/utils/form-utils';
import modalFactory from './global/modal';
import ITSProduct from './custom/its-product';
import DualPanelScroll from './custom/dual-panel-scroll';
import SplitLayoutCarousel from './custom/split-layout-carousel';
import './product/image-gallery';

export default class Product extends PageManager {
    constructor(context) {
        super(context);
        this.url = window.location.href;
        this.$reviewLink = $('[data-reveal-id="modal-review-form"]');
        this.$bulkPricingLink = $('[data-reveal-id="modal-bulk-pricing"]');
        this.reviewModal = modalFactory('#modal-review-form')[0];
    }

    onReady() {
        // Remove hidden product form (mobile or desktop) from the DOM, robust for AJAX/Stencil swaps
        function removeHiddenProductForm() {
            var isMobile = window.innerWidth <= 1024;
            if (isMobile) {
                // Remove desktop form
                var desktopForm = document.querySelector('.details-panel .productView-options form');
                if (desktopForm) desktopForm.remove();
            } else {
                // Remove mobile form
                var mobileForm = document.querySelector('.details-panel-inline .productView-options form');
                if (mobileForm) mobileForm.remove();
            }
        }

        // Initial run
        removeHiddenProductForm();

        // MutationObserver to watch for DOM changes in the product details area
        var productView = document.querySelector('.productView');
        if (productView) {
            var observer = new MutationObserver(function(mutations) {
                // Remove hidden form whenever DOM changes
                removeHiddenProductForm();
            });
            observer.observe(productView, { childList: true, subtree: true });
        }

        // Also run on resize
        window.addEventListener('resize', function() {
            // Only run if both forms are present
            var desktopForm = document.querySelector('.details-panel .productView-options form');
            var mobileForm = document.querySelector('.details-panel-inline .productView-options form');
            if (desktopForm && mobileForm) removeHiddenProductForm();
        });

        // Listen for foundation modal close events to sanitize URL after review.
        $(document).on('close.fndtn.reveal', () => {
            if (this.url.indexOf('#write_review') !== -1 && typeof window.history.replaceState === 'function') {
                window.history.replaceState(null, document.title, window.location.pathname);
            }
        });

        let validator;

        // Init collapsible
        collapsibleFactory();

        this.productDetails = new ProductDetails($('.productView'), this.context, window.BCData.product_attributes);
        this.productDetails.setProductVariant();

        videoGallery();

        this.bulkPricingHandler();

        const $reviewForm = classifyForm('.writeReview-form');

        this.ITSProduct = new ITSProduct(this.context);
        
        // Initialize dual-panel scroll synchronization for split layout
        this.dualPanelScroll = new DualPanelScroll();
        
        // Initialize split layout carousel override
        this.splitLayoutCarousel = new SplitLayoutCarousel();
        
        if ($reviewForm.length === 0) return;

        const review = new Review({ $reviewForm });

        $('body').on('click', '[data-reveal-id="modal-review-form"]', () => {
            validator = review.registerValidation(this.context);
            this.ariaDescribeReviewInputs($reviewForm);
        });

        $reviewForm.on('submit', () => {
            if (validator) {
                validator.performCheck();
                return validator.areAll('valid');
            }

            return false;
        });

        this.productReviewHandler();

        /**
         * IntuitSolutions - Custom Product
         */
    }

    ariaDescribeReviewInputs($form) {
        $form.find('[data-input]').each((_, input) => {
            const $input = $(input);
            const msgSpanId = `${$input.attr('name')}-msg`;

            $input.siblings('span').attr('id', msgSpanId);
            $input.attr('aria-describedby', msgSpanId);
        });
    }

    productReviewHandler() {
        if (this.url.indexOf('#write_review') !== -1) {
            this.$reviewLink.trigger('click');
        }
    }

    bulkPricingHandler() {
        if (this.url.indexOf('#bulk_pricing') !== -1) {
            this.$bulkPricingLink.trigger('click');
        }
    }
}
