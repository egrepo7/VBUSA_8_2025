/*
 Import all product specific js
 */
import PageManager from './page-manager';
import Review from './product/reviews';
import collapsibleFactory from './common/collapsible';
import ProductDetails from './common/product-details';
import videoGallery from './product/video-gallery';
import { classifyForm } from './common/utils/form-utils';
import modalFactory from './global/modal';
import ITSProduct from './custom/its-product';
import DualPanelScroll from './custom/dual-panel-scroll';
import SplitLayoutCarousel from './custom/split-layout-carousel';
import './product/image-gallery';

// Global debug function (available immediately)
window.debugStickyCart = function() {
    console.log('🔧 Debug Sticky Cart Elements:');
    console.log('🔍 All sticky cart sections:', $('.sticky-cart-section').length);
    console.log('🔍 Mobile sticky cart sections:', $('.sticky-cart-section-mobile').length);
    console.log('🔍 Add to cart mobile buttons:', $('#form-action-addToCart-mobile').length);
    console.log('🔍 jQuery loaded:', typeof $ !== 'undefined');
    console.log('🔍 Window width:', $(window).width());
    
    // Log all elements for inspection
    $('.sticky-cart-section').each(function(i, el) {
        console.log(`📦 Sticky cart section ${i}:`, el);
    });
    
    $('.sticky-cart-section-mobile').each(function(i, el) {
        console.log(`📱 Mobile sticky cart section ${i}:`, el, 'visible:', $(el).is(':visible'));
    });
    
    $('#form-action-addToCart-mobile').each(function(i, el) {
        console.log(`🎯 Mobile add to cart button ${i}:`, el);
    });
};

console.log('🚀 debugStickyCart() function is now available globally');

// Test if click events are working at all
$(document).ready(function() {
    console.log('📋 Document ready - testing click handlers');
    
    // Test basic click detection on mobile sticky cart button
    $(document).on('click', '#form-action-addToCart-mobile', function(e) {
        console.log('🎯 BASIC CLICK DETECTED on mobile add to cart button');
        console.log('🔍 Event target:', e.target);
        console.log('🔍 Button closest sticky section:', $(e.target).closest('.sticky-cart-section-mobile').length > 0);
    });
    
    // BACKUP: Direct mobile sticky cart validation handler (since Product class might not be working)
    $(document).on('click', '.sticky-cart-section-mobile #form-action-addToCart-mobile', function(e) {
        console.log('🚀 BACKUP HANDLER: Mobile sticky cart validation triggered');
        
        // Only proceed if sticky cart is visible
        const $stickyCartSection = $('.sticky-cart-section-mobile');
        if (!$stickyCartSection.is(':visible')) {
            console.log('🖥️ Sticky cart not visible, allowing normal behavior');
            return;
        }
        
        const $form = $('#productOptionsForm-inline');
        if (!$form.length) {
            console.log('❌ No inline form found');
            return;
        }
        
        // Prevent default and check for missing required options
        e.preventDefault();
        console.log('🛑 Form submission prevented - checking for required options');
        
        // Simple check for unselected required dropdowns
        const $requiredSelects = $form.find('select[required]');
        const $unselectedRequired = $requiredSelects.filter(function() {
            return $(this).val() === '' || $(this).prop('selectedIndex') === 0;
        }).first();
        
        console.log('🔍 Required selects found:', $requiredSelects.length);
        console.log('🔍 Unselected required:', $unselectedRequired.length);
        
        if ($unselectedRequired.length > 0) {
            console.log('❌ Found unselected required option, scrolling');
            const $container = $unselectedRequired.closest('[data-product-attribute]');
            if ($container.length > 0) {
                console.log('📍 Scrolling to:', $container.find('label').text());
                $('html, body').animate({
                    scrollTop: $container.offset().top - 100
                }, 600, function() {
                    console.log('✅ Scroll completed');
                    $container.addClass('scroll-highlight');
                    setTimeout(() => $container.removeClass('scroll-highlight'), 2000);
                });
            }
        } else {
            console.log('✅ No validation errors, submitting form');
            $form.submit();
        }
    });
    
    // Test if Product class is being instantiated
    window.checkProductClass = function() {
        console.log('🏗️ Checking Product class instantiation:');
        console.log('🔍 Product on window:', typeof window.Product);
        console.log('🔍 ProductDetails on window:', typeof window.productDetails);
        console.log('🔍 Current page type:', document.body.className);
    };
    
    console.log('✅ Basic click test handlers ready - try checkProductClass()');
});

// Set up mobile sticky cart quantity handlers
$(document).ready(function() {
    // Mobile sticky cart quantity handler
    $(document).on('click', '.sticky-cart-section-mobile button[data-action]', function(e) {
        e.preventDefault();
        
        const action = $(this).data('action');
        const $input = $('#qty-mobile');
        
        if (!$input.length || !action) return;
        
        let qty = parseInt($input.val()) || 1;
        const minQty = parseInt($input.data('quantity-min')) || 1;
        const maxQty = parseInt($input.data('quantity-max')) || 999;
        
        if (action === 'inc' && qty < maxQty) {
            qty++;
        } else if (action === 'dec' && qty > minQty) {
            qty--;
        }
        
        // Update mobile input and sync with all other quantity inputs
        $input.val(qty);
        $('[name="qty[]"]').val(qty);
        $('.incrementTotal').text(qty);
        $('[name="qty[]"]').trigger('change');
    });
    
    // Sync mobile input when other quantity inputs change
    $(document).on('change', '[name="qty[]"]:not(#qty-mobile)', function() {
        const newQty = parseInt($(this).val()) || 1;
        $('#qty-mobile').val(newQty);
    });
});

export default class Product extends PageManager {
    constructor(context) {
        super(context);
        this.url = window.location.href;
        this.$reviewLink = $('[data-reveal-id="modal-review-form"]');
        this.$bulkPricingLink = $('[data-reveal-id="modal-bulk-pricing"]');
        this.reviewModal = modalFactory('#modal-review-form')[0];
    }

    onReady() {
        // Remove hidden product form (mobile or desktop) from the DOM, robust for AJAX/Stencil swaps
        function removeHiddenProductForm() {
            var isMobile = window.innerWidth <= 1024;
            if (isMobile) {
                // Remove desktop form
                var desktopForm = document.querySelector('.details-panel .productView-options form');
                if (desktopForm) desktopForm.remove();
            } else {
                // Remove mobile form
                var mobileForm = document.querySelector('.details-panel-inline .productView-options form');
                if (mobileForm) mobileForm.remove();
            }
        }

        // Initial run
        removeHiddenProductForm();

        // MutationObserver to watch for DOM changes in the product details area
        var productView = document.querySelector('.productView');
        if (productView) {
            var observer = new MutationObserver(function(mutations) {
                // Remove hidden form whenever DOM changes
                removeHiddenProductForm();
            });
            observer.observe(productView, { childList: true, subtree: true });
        }

        // Also run on resize
        window.addEventListener('resize', function() {
            // Only run if both forms are present
            var desktopForm = document.querySelector('.details-panel .productView-options form');
            var mobileForm = document.querySelector('.details-panel-inline .productView-options form');
            if (desktopForm && mobileForm) removeHiddenProductForm();
        });

        // Listen for foundation modal close events to sanitize URL after review.
        $(document).on('close.fndtn.reveal', () => {
            if (this.url.indexOf('#write_review') !== -1 && typeof window.history.replaceState === 'function') {
                window.history.replaceState(null, document.title, window.location.pathname);
            }
        });

        let validator;

        // Init collapsible
        collapsibleFactory();

        // Fix duplicate IDs in details-panel-inline by appending '-inline' to all IDs and updating label 'for' attributes
        function fixInlinePanelIds() {
            const $inlinePanel = $('.details-panel-inline');
            $inlinePanel.find('[id]').each(function() {
                const oldId = $(this).attr('id');
                if (!oldId.endsWith('-inline')) {
                    const newId = oldId + '-inline';
                    // Update the element's ID
                    $(this).attr('id', newId);
                    // Update any label referencing this ID
                    $inlinePanel.find(`label[for="${oldId}"]`).attr('for', newId);
                }
            });
        }
        fixInlinePanelIds();

        this.productDetails = new ProductDetails($('.productView'), this.context, window.BCData.product_attributes);
        this.productDetails.setProductVariant();

        // Inline/mobile panel
        if ($('.details-panel-inline').length) {
            this.productDetailsInline = new ProductDetails($('.details-panel-inline'), this.context, window.BCData.product_attributes);
            this.productDetailsInline.setProductVariant();
        }

        // --- Sync product options between main and inline forms ---
        function syncProductOptions(sourceFormSelector, targetFormSelector) {
            const $source = $(sourceFormSelector);
            const $target = $(targetFormSelector);
            $source.find('[name]').each(function() {
                const name = $(this).attr('name');
                // For radio/checkbox, sync checked state; for others, sync value
                const type = $(this).attr('type');
                if (type === 'radio' || type === 'checkbox') {
                    if ($(this).is(':checked')) {
                        $target.find(`[name="${name}"][value="${$(this).val()}"]`).prop('checked', true).trigger('change');
                    }
                } else {
                    $target.find(`[name="${name}"]`).val($(this).val()).trigger('change');
                }
            });
        }
        $('#productOptionsForm').on('change', function() {
            syncProductOptions('#productOptionsForm', '#productOptionsForm-inline');
        });
        $('#productOptionsForm-inline').on('change', function() {
            syncProductOptions('#productOptionsForm-inline', '#productOptionsForm');
        });

        // --- Update price in sticky cart section for inline panel ---
        function updateInlineStickyCartPrice() {
            // Get the updated price from the inline panel
            var inlinePrice = document.querySelector('.details-panel-inline .productView-price');
            var stickyPrice = document.querySelector('.sticky-cart-section-mobile .sticky-cart-product-price');
            if (inlinePrice && stickyPrice) {
                stickyPrice.innerHTML = inlinePrice.innerHTML;
            }
        }
        // Run once on page load
        updateInlineStickyCartPrice();
        // Run whenever product options change in inline panel
        document.querySelector('#productOptionsForm-inline')?.addEventListener('change', function(e) {
            setTimeout(updateInlineStickyCartPrice, 100);
        });
        // Also observe for price changes in inline panel (in case price updates via AJAX)
        var inlinePriceEl = document.querySelector('.details-panel-inline .productView-price');
        if (inlinePriceEl) {
            var observerInlineSticky = new MutationObserver(updateInlineStickyCartPrice);
            observerInlineSticky.observe(inlinePriceEl, { childList: true, subtree: true });
        }

        videoGallery();

        this.bulkPricingHandler();

        const $reviewForm = classifyForm('.writeReview-form');

        this.ITSProduct = new ITSProduct(this.context);
        
        // Initialize dual-panel scroll synchronization for split layout
        this.dualPanelScroll = new DualPanelScroll();
        
        // Initialize split layout carousel override
        this.splitLayoutCarousel = new SplitLayoutCarousel();
        
        if ($reviewForm.length === 0) return;

        const review = new Review({ $reviewForm });

        $('body').on('click', '[data-reveal-id="modal-review-form"]', () => {
            validator = review.registerValidation(this.context);
            this.ariaDescribeReviewInputs($reviewForm);
        });

        $reviewForm.on('submit', () => {
            if (validator) {
                validator.performCheck();
                return validator.areAll('valid');
            }

            return false;
        });

        this.productReviewHandler();

        // --- Sticky Cart Price Sync (Improved) ---
        function updateStickyCartPrice() {
            // Main price area
            var mainWithTax = document.querySelector('.productView .price--withTax');
            var mainWithoutTax = document.querySelector('.productView .price--withoutTax');
            // Sticky cart area
            var stickyWithTax = document.querySelector('.sticky-cart-product-price .price--withTax');
            var stickyWithoutTax = document.querySelector('.sticky-cart-product-price .price--withoutTax');
        
            if (mainWithTax && stickyWithTax) {
                stickyWithTax.innerHTML = mainWithTax.innerHTML;
            }
            if (mainWithoutTax && stickyWithoutTax) {
                stickyWithoutTax.innerHTML = mainWithoutTax.innerHTML;
            }
        }

        // Run once on page load
        updateStickyCartPrice();

        // Run whenever product options change
        document.addEventListener('change', function(e) {
            if (e.target.closest('.productView-options')) {
                setTimeout(updateStickyCartPrice, 100);
            }
        });

        // Also observe for price changes (in case price updates via AJAX)
        var mainPrice = document.querySelector('.productView-price');
        if (mainPrice) {
            var observerPrice = new MutationObserver(updateStickyCartPrice);
            observerPrice.observe(mainPrice, { childList: true, subtree: true });
        }

        // --- Sync data-product-price-without-tax in .details-panel-inline ---
        function updateInlinePanelPrice() {
            // Always copy from desktop/main panel to inline/mobile panel
            var mainPrice = document.querySelector('.details-panel .productView-price [data-product-price-without-tax]');
            var inlinePanel = document.querySelector('.details-panel-inline .productView-price [data-product-price-without-tax]');
            if (mainPrice && inlinePanel) {
                inlinePanel.innerHTML = mainPrice.innerHTML;
            }
        }

        // Run once on page load
        updateInlinePanelPrice();

        // Run whenever product options change
        document.addEventListener('change', function(e) {
            if (e.target.closest('.productView-options')) {
                setTimeout(updateInlinePanelPrice, 100);
            }
        });

        // Also observe for price changes (in case price updates via AJAX)
        var mainPriceInline = document.querySelector('.details-panel .productView-price [data-product-price-without-tax]');
        if (mainPriceInline) {
            var observerInline = new MutationObserver(updateInlinePanelPrice);
            observerInline.observe(mainPriceInline, { childList: true, subtree: true });
        }

        // --- Mobile Sticky Cart Validation & Scroll Handler ---
        this.setupMobileStickyCartHandler();
        
        // Global test function for immediate debugging
        window.testMobileStickyCart = () => {
            const $button = $('.sticky-cart-section-mobile #form-action-addToCart-mobile');
            const $section = $('.sticky-cart-section-mobile');
            console.log('🧪 Global Mobile Sticky Cart Test:');
            console.log('📱 Button found:', $button.length > 0);
            console.log('📱 Section found:', $section.length > 0);
            console.log('👁️ Section visible:', $section.is(':visible'));
            console.log('🎯 Current viewport width:', $(window).width());
            console.log('🔍 Button element:', $button[0]);
            console.log('🔍 Section element:', $section[0]);
            return {
                buttonExists: $button.length > 0,
                sectionExists: $section.length > 0,
                sectionVisible: $section.is(':visible'),
                viewportWidth: $(window).width(),
                buttonElement: $button[0],
                sectionElement: $section[0]
            };
        };
        
        console.log('✅ Product onReady completed - testMobileStickyCart() should now be available');
    }

    setupMobileStickyCartHandler() {
        console.log('🚀 Mobile sticky cart handler initialized - CHECKING IF THIS RUNS');
        console.log('🔍 setupMobileStickyCartHandler method called at:', new Date().toLocaleTimeString());
        
        // Expose a test function for debugging
        window.testMobileStickyCart = () => {
            const $button = $('.sticky-cart-section-mobile #form-action-addToCart-mobile');
            const $section = $('.sticky-cart-section-mobile');
            console.log('🧪 Mobile Sticky Cart Test:');
            console.log('📱 Button found:', $button.length > 0);
            console.log('📱 Section found:', $section.length > 0);
            console.log('👁️ Section visible:', $section.is(':visible'));
            console.log('🎯 Current viewport width:', $(window).width());
            return {
                buttonExists: $button.length > 0,
                sectionExists: $section.length > 0,
                sectionVisible: $section.is(':visible'),
                viewportWidth: $(window).width()
            };
        };
        
        // Only handle clicks on the mobile sticky cart button (when sticky cart is visible)
        $(document).on('click', '.sticky-cart-section-mobile #form-action-addToCart-mobile', (event) => {
            console.log('📱 Mobile sticky cart button clicked');
            
            // Only proceed if the sticky cart section is actually visible (mobile view)
            const $stickyCartSection = $('.sticky-cart-section-mobile');
            if (!$stickyCartSection.is(':visible')) {
                console.log('🖥️ Sticky cart not visible (desktop view), allowing normal behavior');
                return; // Let normal form submission happen on desktop
            }
            
            const $mobileButton = $(event.target);
            const formSelector = $mobileButton.attr('form'); // Gets "productOptionsForm-inline"
            const $form = $(`#${formSelector}`);
            
            console.log('📋 Form selector:', formSelector);
            console.log('📋 Form found:', $form.length > 0);
            
            if (!$form.length) {
                console.log('❌ No form found, returning');
                return;
            }

            // Prevent the default submit to handle validation first
            event.preventDefault();
            console.log('🛑 Default form submission prevented for mobile sticky cart');
            
            // Get the ProductDetails instance that handles this form
            let productDetailsInstance = null;
            
            // Check if this is the inline form (mobile panel)
            if (formSelector === 'productOptionsForm-inline' && this.productDetailsInline) {
                productDetailsInstance = this.productDetailsInline;
                console.log('✅ Using inline ProductDetails instance');
            } else if (this.productDetails) {
                productDetailsInstance = this.productDetails;
                console.log('✅ Using main ProductDetails instance');
            }
            
            if (!productDetailsInstance || !productDetailsInstance.addToCartValidator) {
                console.log('❌ No ProductDetails instance or validator found, submitting normally');
                // Fallback: submit the form normally
                $form.submit();
                return;
            }
            
            console.log('🔍 Running validation...');
            // Run validation
            productDetailsInstance.addToCartValidator.performCheck();
            
            if (productDetailsInstance.addToCartValidator.areAll('valid')) {
                console.log('✅ Validation passed - submitting form');
                // Validation passed - submit the form
                $form.submit();
            } else {
                console.log('❌ Validation failed - triggering scroll to first error');
                // Validation failed - scroll to first error
                this.scrollToFirstValidationError($form);
            }
        });
    }

    scrollToFirstValidationError($form) {
        console.log('🔍 Starting scroll to first validation error');
        console.log('📋 Form to check:', $form.attr('id') || 'unnamed form');
        
        // Wait a moment for validation classes to be applied
        setTimeout(() => {
            console.log('⏱️ After 100ms delay, looking for error fields...');
            
            // Find the first field with validation error
            let $firstError = $form.find('.form-field--error').first();
            console.log('🔍 Error fields in form:', $form.find('.form-field--error').length);
            
            // If no error fields found in the form, check the entire page
            if ($firstError.length === 0) {
                $firstError = $('.form-field--error').first();
                console.log('🔍 Error fields on entire page:', $('.form-field--error').length);
            }
            
            if ($firstError.length > 0) {
                console.log('✅ Found error field:', $firstError.attr('class') || 'no class');
                console.log('📍 Error field location:', $firstError.offset());
                // Scroll to the specific error field
                this.smoothScrollToElement($firstError, 'Error Field');
            } else {
                console.log('🔍 No error fields found, looking for unselected required options...');
                
                // Fallback: find first required option that's not selected
                const $unselectedRequired = $form.find('[data-product-attribute] select').filter(function() {
                    const $select = $(this);
                    const $container = $select.closest('[data-product-attribute]');
                    const isRequired = $container.find('label').text().toLowerCase().includes('required');
                    const isUnselected = ($select.val() === '' || $select.prop('selectedIndex') === 0);
                    
                    if (isRequired && isUnselected) {
                        console.log('🎯 Found unselected required option:', $container.find('label').text().trim());
                    }
                    
                    return isRequired && isUnselected;
                }).first().closest('[data-product-attribute]');
                
                if ($unselectedRequired.length > 0) {
                    console.log('✅ Scrolling to unselected required option');
                    this.smoothScrollToElement($unselectedRequired, 'Required Option');
                } else {
                    console.log('🔍 No unselected required options, looking for product options section...');
                    
                    // Fallback: scroll to the product options section
                    const $productOptions = $form.find('[data-product-option-change]').first();
                    if ($productOptions.length > 0) {
                        console.log('✅ Scrolling to product options section');
                        this.smoothScrollToElement($productOptions, 'Product Options Section');
                    } else {
                        console.log('🔍 No product options section, scrolling to form itself');
                        // Final fallback: scroll to the form itself
                        this.smoothScrollToElement($form, 'Form Itself');
                    }
                }
            }
        }, 100);
    }

    smoothScrollToElement($element, elementType = 'Element') {
        if (!$element.length) {
            console.log('❌ No element to scroll to');
            return;
        }
        
        const offset = 100; // Offset from top of viewport
        const currentScrollTop = $(window).scrollTop();
        const elementOffset = $element.offset();
        const targetPosition = elementOffset.top - offset;
        
        console.log(`🎯 Scrolling to ${elementType}:`);
        console.log('📍 Element offset:', elementOffset);
        console.log('📏 Current scroll position:', currentScrollTop);
        console.log('📏 Target scroll position:', targetPosition);
        console.log('📐 Distance to scroll:', Math.abs(targetPosition - currentScrollTop), 'pixels');
        
        $('html, body').animate({
            scrollTop: targetPosition
        }, {
            duration: 600,
            easing: 'swing',
            start: () => {
                console.log('🎬 Scroll animation started');
            },
            complete: () => {
                console.log('✅ Scroll animation completed');
                console.log('📏 Final scroll position:', $(window).scrollTop());
                
                // Add a subtle highlight effect to draw attention to the target
                $element.addClass('scroll-highlight');
                console.log('✨ Highlight effect applied');
                
                setTimeout(() => {
                    $element.removeClass('scroll-highlight');
                    console.log('✨ Highlight effect removed');
                }, 2000);
            }
        });
    }

    ariaDescribeReviewInputs($form) {
        $form.find('[data-input]').each((_, input) => {
            const $input = $(input);
            const msgSpanId = `${$input.attr('name')}-msg`;

            $input.siblings('span').attr('id', msgSpanId);
            $input.attr('aria-describedby', msgSpanId);
        });
    }

    productReviewHandler() {
        if (this.url.indexOf('#write_review') !== -1) {
            this.$reviewLink.trigger('click');
        }
    }

    bulkPricingHandler() {
        if (this.url.indexOf('#bulk_pricing') !== -1) {
            this.$bulkPricingLink.trigger('click');
        }
    }
}
