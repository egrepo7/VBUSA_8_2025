import { api } from '@bigcommerce/stencil-utils';
import urlUtils from '../common/utils/url-utils';

export default class ToggleCategoryListingView {
    constructor(context) {
        // EMERGENCY: Block this entire class for volleyball nets page
        if (window.customVolleyballNetsPage || window.blockToggleCategoryListingView || window.emergencyCarouselProtection) {
            console.log('TOGGLE-CATEGORY-LISTING-VIEW: Completely blocked for volleyball nets page');
            // Return a safe, non-functional object
            this.init = () => { console.log('ToggleCategoryListingView.init() blocked'); };
            this.fullWidthTemplate = () => { console.log('ToggleCategoryListingView.fullWidthTemplate() blocked'); return false; };
            this.getRequestTemplateType = () => { console.log('ToggleCategoryListingView.getRequestTemplateType() blocked'); return 'grid'; };
            this.destroy = () => { console.log('ToggleCategoryListingView.destroy() blocked'); };
            return;
        }

        this.context = context;
        this.defaultViewType = this.context.defaultViewType || 'list'; // Fallback to list if not set
        this.oppositeViewType = this.defaultViewType !== 'grid' ? 'grid' : 'list';
        this.productsPerPage = this.context.categoryProductsPerPage;
        this.loadingOverlay = $('.loadingOverlay.loadingOverlay--product-listing');

        // Debug logging for browser differences and localhost issues
        console.log('ToggleCategoryListingView initialized:', {
            defaultViewType: this.defaultViewType,
            oppositeViewType: this.oppositeViewType,
            storedViewType: sessionStorage.getItem('category-view-type'),
            userAgent: navigator.userAgent.includes('Chrome') ? 'Chrome' : 
                      navigator.userAgent.includes('Safari') ? 'Safari' : 'Other',
            isLocalhost: window.location.hostname.includes('localhost') || window.location.hostname.includes('127.0.0.1'),
            contextDefaultView: this.context.defaultViewType
        });

        $('body').on('facetedSearchRefresh', () => {
            this.addToggleEvents();
        });

        this.init();
        this.fullWidthTemplate();
    }

    getProductDescriptions() {
        if ($('.listItem').length) {
            console.log('IntuitSolutions -- Category Product Descriptions');

            const $products = $('.listItem').toArray();
            
            const $productIDs = $products.map(item => {
                return Number($(item).attr('data-entity-id'));
            });
            
            const $graphQLToken = $('body').data('graphql');
            fetch('/graphql', {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${$graphQLToken}`
                },
                body: JSON.stringify({
                    query: `query {
                        site {
                            products(entityIds: [${$productIDs}], first: ${this.context.categoryProductsPerPage}) {
                                edges {
                                    node {
                                        entityId
                                        name
                                        description
                                    }
                                }
                            }
                        }
                    }`,
                }),
            })
            .then(res => res.json())
            .then(request => {
                const gqlProducts = request.data.site.products.edges;
                console.log(gqlProducts);

                $products.forEach((product, i) => {
                    gqlProducts.forEach(item => {
                        if ($(product).data('entityId') === item.node.entityId) {
                            $(product).find('.listItem__description').html(item.node.description);
                        }
                    })
                });
            });
        }
    }

    getStoredViewType() {
        return sessionStorage.getItem('category-view-type') || null;
    }

    getRequestTemplateType(type) {
        const pageType = this.getStoredViewType();
        return !pageType ? `${type}/product-listing` : `custom/category-${pageType}-view`;
    }

    storeViewType(type) {
        sessionStorage.setItem('category-view-type', type);
    }

    addStyleClass() {
        if ($('.listItem').length) {
            $('body').addClass('list-view');
        } else {
            $('body').removeClass('list-view');
        }
    }

    getCategoryPage(pageType) {
        const config = {
            config: {
                category: {
                    shop_by_price: true,
                    products: {
                        limit: this.productsPerPage,
                    },
                },
            },
            template: `custom/category-${pageType}-view`,
        };

        this.loadingOverlay.show();

        api.getPage(urlUtils.getUrl(), config, (err, content) => {
            if (err) {
                throw new Error(err);
            }

            $('#product-listing-container').html(content);

            this.loadingOverlay.hide();

            this.storeViewType(pageType);

            this.addToggleEvents();

            // Trigger events for filter restoration
            $('body').triggerHandler('productViewModeChanged');
            
            // Also trigger a more specific event for filter tabs
            $('body').triggerHandler('categoryFilterTabsRefresh');

            this.fullWidthTemplate();
        });
    }

    addToggleEvents() {
        $('.js-category__toggle-view').on('click', (e) => {
            const type = $(e.currentTarget).data('view-type');

            if ($(e.currentTarget).hasClass('active-category-view')) return;

            this.getCategoryPage(type, this.addToggleEvents);
        });
    }

    fullWidthTemplate() {
        if ($('.list-full-width').length) {
            this.getProductDescriptions();
            this.addStyleClass();

            // aGFja3kgc29sdXRpb24=
            $(window).on('load', () => {
                $('.list-img-container').toArray().forEach(img => {
                    if ($(img).height() > 620) {
                        $(img).addClass('adjust-list-img-height');
                    }
                })
            });
        }
    }

    init() {
        const storedViewType = this.getStoredViewType();
        
        // Enhanced detection for filter tabs template
        const isFilterTabsTemplate = window.location.pathname.includes('nets') || 
                                   document.querySelector('.category-hero--filter-tabs') ||
                                   document.querySelector('.subcategory-tabs--alt') ||
                                   document.body.classList.contains('category-filter-tabs');
        
        console.log('Init debug:', {
            storedViewType,
            defaultViewType: this.defaultViewType,
            isFilterTabsTemplate,
            pathname: window.location.pathname,
            isLocalhost: window.location.hostname.includes('localhost') || window.location.hostname.includes('127.0.0.1')
        });
        
        // ALWAYS respect the defaultViewType from theme settings for initial load
        // This fixes the localhost/browsersync issue where it defaults to grid
        if (!storedViewType) {
            console.log('No stored view type - using theme default:', this.defaultViewType);
            // If default is list, make sure we're in list view without making an AJAX call
            if (this.defaultViewType === 'list') {
                this.addStyleClass(); // Add list-view class if needed
            }
            return this.addToggleEvents();
        }
        
        // For filter tabs template, always respect the injected defaultViewType
        if (isFilterTabsTemplate) {
            // Clear any conflicting stored view type for filter tabs
            if (storedViewType !== this.defaultViewType) {
                console.log('Clearing conflicting stored view type for filter tabs');
                sessionStorage.removeItem('category-view-type');
            }
            // Force the default view type for filter tabs
            return this.addToggleEvents();
        }

        // For regular category pages with stored preference
        if (storedViewType === this.defaultViewType) {
            return this.addToggleEvents();
        }

        // Only switch to stored view if it's different from default
        console.log('Switching to stored view type:', storedViewType);
        this.getCategoryPage(storedViewType);
    }
}
