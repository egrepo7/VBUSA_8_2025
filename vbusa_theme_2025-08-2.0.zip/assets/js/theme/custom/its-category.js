export default class ITSCategory {
    constructor(context) {
        this.context = context;
    }

    afterFacetUpdate() {

    }
}
